Thanks for your interesting in our work.

These files include both of the results and a simple implementation of our double opponent mechanisms based color constancy model in Matlab. 
Everybody can directly utilize the results on three datasets without running again the algorithms of our ICCV13 paper.  

This code can only be used for academic research. 

If you use these materials in your research work, please cite our paper: 
Shaobing Gao, Kaifu Yang, Chaoyi Li, Yongjie Li*. A Color Constancy Model with Double-Opponent Mechanisms. Proceeding of IEEE International Conference on Computer Vision (ICCV), pp.929-936, 2013.

Any questions, please contact: 
Email: gao_shaobing@163.com (Shaobing Gao)

Address:
Visual Cognition and Computation Lab (VCCL),
Key Laboratory for Neuroinformation of Ministry of Education,
School of Life Science and Technology,
University of Electronic Science and Technology of China,
North Jianshe Road,
Chengdu, 610054, China


Directly running the code, you can obtain the following result:
